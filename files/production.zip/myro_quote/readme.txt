Gerbers:

.GBL - bottom copper
.GTL - top copper
.GBP - bottom paste
.GTP - top paste
.GBS - bottom soldermask
.GTS - top soldermask
.GBO - bottom silkscreen
.GTO - top silkscreen
.TXT - drill file

Placement files top and bottom are included as PDF - note that the bottom placement is a BOTTOM VIEW!