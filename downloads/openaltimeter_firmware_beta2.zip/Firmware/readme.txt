Open altimeter firmware
=======================

Changelog
---------

beta1: Initial version. Working altimeter logging and launch height output. Code is mostly there for lost-model-
and low-voltage- alarms, but not enabled.
