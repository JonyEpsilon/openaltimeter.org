Open altimeter firmware
=======================

