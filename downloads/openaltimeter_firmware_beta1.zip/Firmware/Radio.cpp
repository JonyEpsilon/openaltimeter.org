/*
    Open Altimeter -- an open-source altimeter for RC aircraft
    Copyright (C) 2010  Jony Hudson
    http://j-star.org/openaltimeter/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "config.h"
#include "Radio.h"
#include "WProgram.h"

#define RADIO_TIMEOUT 15000

Radio::Radio(int inputPin)
{
  _inputPin = inputPin;
}

void Radio::setup()
{
  pinMode(_inputPin, INPUT);
  // enable the pull-up to stop spurious triggering
  digitalWrite(_inputPin, HIGH);
}

uint16_t Radio::getRawValue()
{
  uint16_t rawVal = pulseIn(_inputPin, HIGH, RADIO_TIMEOUT);
  return rawVal;
}

uint8_t Radio::getState()
{
  uint16_t rawValue = getRawValue();
  if (rawValue < RADIO_MID_THRESHOLD_LOW) return RADIO_SWITCH_OFF;
  if (rawValue > RADIO_MID_THRESHOLD_HIGH) return RADIO_SWITCH_ON;
  return RADIO_SWITCH_MID;
}

void Radio::test()
{
  // TODO
}

