/*
    openaltimeter -- an open-source altimeter for RC aircraft
    Copyright (C) 2010  Jony Hudson
    http://openaltimeter.org

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DATASTORE_H
#define DATASTORE_H

#include "AT25DF.h"

#include "WProgram.h"
#include "config.h"

#define DATASTORE_LOG_ENTRY_SIZE sizeof(LogEntry)
#define DATASTORE_MAX_ENTRIES (uint32_t)(((double)AT25DF_SIZE / (double)DATASTORE_LOG_ENTRY_SIZE) - 2)  // the - 2 makes sure that there are always a
                                                                                                        // couple of null records at the end.

class LogEntry
{
  public:
    int32_t pressure;
    int32_t temperature;
    float battery;
    void print();
};

class Datastore
{
  public:
    Datastore(AT25DF* flash);
    void setup();
    void addEntry(LogEntry* logEntry);
    void addFileEndMarker();
    void startRead();
    void getNextEntry(LogEntry* buffer);
    boolean entryAvailable();
    void startReverseRead();
    void getPreviousEntry(LogEntry* buffer);
    boolean entryReverseAvailable();
    void erase();
    uint32_t getNumberOfFiles();
    uint32_t getNumberOfEntries();
    void testWrite(int n);
    void test();
  private:
    AT25DF* _flash;
    uint32_t _firstFreeAddress;
    uint32_t _numberOfFiles;
    uint32_t _readPointer;
    void scanFlash();
};

#endif /*DATASTORE_H*/
