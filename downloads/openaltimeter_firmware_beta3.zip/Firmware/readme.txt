openaltimeter firmware
=======================

Changelog
---------

beta3: Enable low-voltage and lost-model alarms. Hysteresis for battery monitor to stop low-voltage alarm from
repeatedly starting and stopping near threshold. Change beeper frequency which, despite the claims of the beeper
datasheet, make the alarms _way_ louder. Make radio pulse measurement more robust. Minor bugfixes.

beta2: Very minor changes to make a usable build. Bugfixes.

beta1: Initial version. Working altimeter logging and launch height output. Code is mostly there for lost-model-
and low-voltage- alarms, but not enabled.
